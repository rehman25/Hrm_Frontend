import React from 'react'
import Header from '../components/Includes/Header';
import DepartmentList from './components/DepartmentList'

const HR_DepartmentList = () => {
    return (
        <>
            <div>
                <Header />
            </div>
            <div className='mt-5'>
                <DepartmentList />
            </div>
        </>
    )
}

export default HR_DepartmentList