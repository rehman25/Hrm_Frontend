import React, { useEffect, useState } from "react";
import { Link , useNavigate} from "react-router-dom";
import '../assets/css/EmployeeTypeList.css'
import secureLocalStorage from 'react-secure-storage';
import EmpListForm from "../form/EmpListForm";
const config = require('../../config.json')


function EmployeeTypeList(props) {
  const [renderInputs, setrenderInputs] = useState([
    { name: "Employee Type", type: "text"},
    { name: "Employee Type Abbrivation", type: "text", },
    { name: "Sort key", type: "text" },
    { name: "Company Code", type: "number", },
    { name: "Retirement Age", type: "number" },
    { name: "Permanant Flag", type: "checkbox", value:"Check"},
    { name: "Company Employee Flag", type: "checkbox", value: "Check" },
    { name: "Probation Month", type: "month"},
    { name: "Change Probation Month", type: "select" },
  ])

  // console.log("renderInputs", renderInputs)
  var get_refresh_token = secureLocalStorage.getItem("refresh");
  var get_access_token = secureLocalStorage.getItem("access_token");
  const navigate = useNavigate()

  const [getList, setGetList] = useState([]);
  const [getInfoErr, setInfoErr] = useState(false);


  async function GetEmpList() {
    await fetch(
      `${config["baseUrl"]}/employment_type_code/GetEmploymentTypeCode`,
      {
        method: "GET",
        headers: {
          "content-type": "application/json",
          accessToken: `Bareer ${get_access_token}`,
        },
      }
    )
      .then((response) => {
        return response.json();
      })
      .then(async (response) => {
        if (response.messsage == "unauthorized") {
          await fetch(
            `${config["baseUrl"]}/employment_type_code/GetEmploymentTypeCode`,
            {
              method: "GET",
              headers: {
                "content-type": "application/json",
                refereshToken: `Bareer ${get_refresh_token}`,
              },
            }
          )
            .then((response) => {
              return response.json();
            })
            .then((response) => {
              if (response.messsage == "timeout error") {
                navigate("/");
              } else {
                secureLocalStorage.setItem("refresh", response.referesh_token);
                secureLocalStorage.setItem(
                  "access_token",
                  response.access_token
                );
                setGetList(response.data);
                
              }
            })
            .catch((error) => {
              setInfoErr(error.message);
            });
          } else {
            setGetList(response.data);
          // console.log(response.data, "Response")
          }
        })
      .catch((error) => {
        setInfoErr(error.message);
      });
  }


  useEffect(() => {
    GetEmpList()
  }, [])

  return (
    <>
      <div className="container-fluid p3">
        <div className="container-fluid mt-2 EmployeeListContainer ">
          <span className="EmployeeListHeader py-2">
            Employee Type List
          </span>
          <div className="row mt-2 p-3">
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">Code</th>
                  <th scope="col">Type Name</th>
                  <th scope="col">Abberviation</th>
                  <th scope="col">Company Employee</th>
                  <th scope="col">Short Key</th>
                  <th scope="col">Edit</th>
                  <th scope="col">Delete</th>
                </tr>
              </thead>
              <tbody className="table-group-divider">
                {getList?.map((items) => {
                  return(
                    <tr>
                      <td>{items.Empt_Type_code}</td>
                      <td>{items.Empt_Type_name}</td>
                      <td>{items.Empt_Type_abbr}</td>
                      <td>{items.Company_Employee_Flag}</td>
                      <td>{items.Sort_key}</td>
                      <td><button className="editBtnTable">Edit</button></td>
                      <td><button className="deleteBtnTable">Delete</button></td>
                </tr>
                  )
                })}
               
              </tbody>
            </table>
            <div className="row mt-1">
              <div className="col-md-12 col-sm-12 p-2">
                <div className="EmployeeListbtncontainer">
                  <Link type="submit" className='btn btn-dark' to={'/EmpListForm'}
                    onClick={()=> {
                      sessionStorage.setItem("FormData", JSON.stringify(renderInputs))
                      sessionStorage.setItem("whichForm", "CreateEmpType")
                    }}
                  >Add New</Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
    
  );
}

export default EmployeeTypeList;