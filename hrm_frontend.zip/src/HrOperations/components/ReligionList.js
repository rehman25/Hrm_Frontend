import {useState} from "react";
import { Link } from "react-router-dom";
import "../assets/css/ReligionList.css";

function ReligionList() {

    const [renderInputs, setrenderInputs] = useState([
        { name: "Religion Name", type: "text" },
        { name: "Religion Abbrivation", type: "text" },
        { name: "Sort Key", type: "text"},
    ])

    return (
        <div className="container-fluid p-2">
            <div className="container-fluid mt-2  ReligionListContainer">
                <span className="ReligionListHeader py-2">Religion List</span>
                {/* <div className="row mt-1 p-2">
                    <div className="col-lg-5 d-flex align-items-center">
                        <input type="text" name="" id="" className="form-control ResignationsListInput" />
                        <button className="btn btn-dark mx-1">Search</button>
                    </div>
                </div> */}
                <div className="row p-3">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Code</th>
                                <th scope="col">Religion Name</th>
                                <th scope="col">Religion Abbreviation</th>
                                <th scope="col">Short Key</th>
                                <th scope="col">Edit</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">1</th>
                                <td>Mark</td>
                                <td>Mark</td>
                                <td>Mark</td>
                                <td><button className="editBtnTable">Edit</button></td>
                                <td><button className="deleteBtnTable">Delete</button></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div className="row mt-1 p-3">
                    <div className="col-md-12 col-sm-12 p-2">
                        <div className="">
                            <Link type="submit" className='btn btn-dark' to={'/EmpListForm'}
                                onClick={() => {
                                    sessionStorage.setItem("FormData", JSON.stringify(renderInputs))
                                    sessionStorage.setItem("whichForm", "CreateReligion")
                                }}
                            >Add New</Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ReligionList;
