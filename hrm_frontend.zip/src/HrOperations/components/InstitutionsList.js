import {useState} from "react";
import { Link } from "react-router-dom";

import "../assets/css/InstitutionsList.css";

function InstitutionsList() {

    const [renderInputs, setrenderInputs] = useState([
        { name: "Institution Name", type: "text" },
        { name: "Institution Abbrivation", type: "text", },
        { name: "Institution Type", type: "text", },
        { name: "Institution Address line1", type: "text", },
        { name: "Institution Address line2", type: "text", },
        { name: "Institution Address line3", type: "text", },
        { name: "Institution Phone1", type: "number" },
        { name: "Institution Phone2", type: "number" },
        { name: "Institution Fax1", type: "number" },
        { name: "Institution Fax2", type: "number" },
        { name: "Institution Email", type: "text" },
        { name: "Institution Website", type: "text" },
        { name: "Sort Key", type: "text" },
        { name: "Verification Fee", type: "number" },
    ])


    return (
        <div className="container-fluid p-2">
            <div className="container-fluid mt-2  InstitutionsListContainer">
                <span className="InstitutionsListHeader py-2">Institutions List</span>
                <div className="row mt-1 p-2">
                    <div className="col-lg-5 d-flex align-items-center">
                        <input type="text" name="" id="" className="form-control InstitutionsListInput" />
                        <button className="btn btn-dark mx-1">Search</button>
                    </div>
                </div>
                <div className="row p-3">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Code</th>
                                <th scope="col">Name</th>
                                <th scope="col">Abbreviation</th>
                                <th scope="col">Institutions Type</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Fax</th>
                                <th scope="col">Short Key</th>
                                <th scope="col">Edit</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">1</th>
                                <td>Mark</td>
                                <td>Mark</td>
                                <td>Mark</td>
                                <td>Mark</td>
                                <td>Mark</td>
                                <td>Mark</td>
                                <td><button className="editBtnTable">Edit</button></td>
                                <td><button className="deleteBtnTable">Delete</button></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div className="row mt-1 p-3">
                    <div className="col-md-12 col-sm-12 p-2">
                        <div className="">
                            <Link type="submit" className='btn btn-dark' to={'/EmpListForm'}
                                onClick={() => {
                                    sessionStorage.setItem("FormData", JSON.stringify(renderInputs))
                                    sessionStorage.setItem("whichForm", "CreateInstitute")
                                }}
                            >Add New</Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default InstitutionsList;
