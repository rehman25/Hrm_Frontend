import {useState} from "react";
import { Link } from "react-router-dom";
import "../assets/css/GradeList.css";
function GradeList() {
  const [renderInputs, setrenderInputs] = useState([
    { name: "Grade Name", type: "text" },
    { name: "Grade Abbr", type: "text", },
    { name: "Probation Months", type: "number" },
    { name: "Incentive Hour Rate", type: "number", },
    { name: "Incentive Weekdays Limit Hour", type: "number" },
    { name: "Incentive Saturday Limit Hour", type: "number" },
    { name: "Medical Insurance Amount", type: "number" },
    { name: "Meal Deduction", type: "number" },
    { name: "Sort Key", type: "text" },
    { name: "Litres For Petrol", type: "number" },
    { name: "Insurance Category", type: "text" },
    { name: "Life Insurance Category", type: "text" },
    { name: "Long Name", type: "text" },
    { name: "Job Description Flag", type: "checkbox", value : "check" },
    { name: "Next Promotion Grade", type: "number" },
    { name: "Assigning Critaria For Next Promotion", type: "number" },
    { name: "Overtime Flag", type: "text", },
    { name: "Mobile Amount", type: "number" },
    { name: "Car Amount", type: "number" },

  ])


  return (
    <div className="container-fluid p-3">
      <div className="container-fluid mt-2  GradeListContainer">
        <span className="GradeListHeader py-2">Grade Centers List</span>
        <div className="row mt-3 px-2 GradeListRaw">
          <div className="ResTable">
          <table className="table table-striped ">
            <thead>
              <tr>
                <th scope="col">Code</th>
                <th scope="col">Name</th>
                <th scope="col">Abbreviation</th>
                <th scope="col">Probation(Months)</th>
                <th scope="col">Incentive Rate</th>
                <th scope="col">Incentive Weekdays Limit (Hours)</th>
                <th scope="col">Incentive Saturday Limit (Hours)</th>
                <th scope="col">Medical Insurance Amount</th>
                <th scope="col">Meal Deduction Amount</th>
                <th scope="col">Petrol</th>
                <th scope="col">Sort Key</th>
                <th scope="col">Next Promotion Required Grade</th>
                <th scope="col">Next Promotion Required Year</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Mark</td>
                <td>Otto</td>
                <td>@mdo</td>
                <td>10000</td>
                <td>10000</td>
                <td>40</td>
                <td>5</td>
                <td>32000</td>
                <td>3200</td>
                <td>5000</td>
                <td>0</td>
                <td>0</td>
                <td>
                  <button className="editBtnTable">Edit</button>
                </td>
                <td>
                  <button className="deleteBtnTable">Delete</button>
                </td>
              </tr>
            </tbody>
          </table>
          </div>
        </div>
        <div className="row mt-1 p-3">
          <div className="col-md-12 col-sm-12 p-2">
            <div className="    ">
              <Link type="submit" className='btn btn-dark' to={'/EmpListForm'}
                onClick={() => {
                  sessionStorage.setItem("FormData", JSON.stringify(renderInputs))
                  sessionStorage.setItem("whichForm", "CreateGradeList")
                }}
              >Add New</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default GradeList;
