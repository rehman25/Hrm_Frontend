import React, { useEffect, useState } from 'react'
import Header from '../../components/Includes/Header'
import './assets/css/HREmpListForm.css'
import { Link, useNavigate } from 'react-router-dom'
import secureLocalStorage from 'react-secure-storage'
import { inputAdornmentClasses } from '@mui/material'
const config = require('../../config.json')

const EmpListForm = () => {
    const [getFormData, setgetFormData] = useState(sessionStorage.getItem("FormData"))
    const [convertData, setCovertData] = useState(JSON.parse(getFormData))
    const [whichForm, setwhichForm] = useState(false)

    const [textInput, settextInput] = useState({})
    const [numberInput, setnumberInput] = useState({})
    const [checkBoxInput, setCheckBoxInput] = useState({})
    const [dateInput, setdateInput] = useState({})
    const [selectTag, setselectTag] = useState({})


    const [loading, setLoading] = useState(false);
    const [btnEnaledAndDisabled, setBtnEnaledAndDisabled] = useState(false);
    const [formErr, setformErr] = useState(false)
    var get_refresh_token = secureLocalStorage.getItem("refresh");
    var get_access_token = secureLocalStorage.getItem("access_token");
    
    const navigate = useNavigate()

    const showAlert = (message, type) => {
        setformErr({
            message: message,
            type: type,
        })
    }


const CreateEmpTypeData = JSON.stringify({
    "Empt_Type_code": 0,
    "Empt_Type_name": textInput.Employee_Type,
    "Empt_Type_abbr": textInput.Employee_Type_Abbrivation,
    "Company_Employee_Flag": checkBoxInput.Company_Employee_Flag,
    "Emp_Code_Prefix": numberInput.Company_Code,
    "PermanantFlag": checkBoxInput.Permanant_Flag,
    "Retirement_Age": numberInput.Retirement_Age,
    "ProbationMonths": dateInput.Probation_Month,
    "AllowChangeProbationMonths": selectTag.Change_Probation_Month,
    "Sort_key": textInput.Sort_key,
})
const CreateEmpType = async (e) => {
    e.preventDefault();
    setLoading(true);
    setBtnEnaledAndDisabled(true);
    await fetch(`${config['baseUrl']}/employment_type_code/AddEmploymentType`, {
        method: "POST",
        headers: { "content-type": "application/json", "accessToken": `Bareer ${get_access_token}` },
        body: CreateEmpTypeData
    }).then((response) => {
        return response.json()
    }).then(async (response) => {
        if (response.messsage == "unauthorized") {
            await fetch(`${config['baseUrl']}/employment_type_code/AddEmploymentType`, {
                method: "POST",
                headers: { "content-type": "application/json", "refereshToken": `Bareer ${get_refresh_token}` },
                body: CreateEmpTypeData
            }).then(response => {
                return response.json()
            }).then(response => {
                secureLocalStorage.setItem("refresh", response.referesh_token);
                secureLocalStorage.setItem("access_token", response.access_token);
                setLoading(false);
                setBtnEnaledAndDisabled(false);
                showAlert(response.messsage, "success")
                setTimeout(() => {
                    window.location.reload();
                }, 1000)
            }).catch((errs) => { 
                setLoading(false);
                setBtnEnaledAndDisabled(false);
                showAlert(errs.messsage, "warning") 
            })
        }
        else if (response.messsage == "timeout error") { navigate('/') }
        else {
            setLoading(false);
            setBtnEnaledAndDisabled(false);
            showAlert(response.messsage, "success")
            setTimeout(() => {
                window.location.reload();
            }, 1000)
        }
    }).catch((errs) => {
        setLoading(false);
        setBtnEnaledAndDisabled(false);
        showAlert(errs.messsage, "warning")
    })
}

// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
const CreateEmpCatData = JSON.stringify({
    "Emp_Category_code": 0,
    "Emp_Category_name": textInput.Employee_cat_Name,
    "Emp_Category_abbr": textInput.Emp_Category_abbr,
    "graduity_fund_percentage": numberInput.graduity_fund_percentage,
    "Sort_key": textInput.Sort_key,
})
const CreateEmpCat = async (e) => {
        e.preventDefault();
        setLoading(true);
        setBtnEnaledAndDisabled(true);
        await fetch(`${config['baseUrl']}/employment_category/AddEmploymentCategory`, {
            method: "POST",
            headers: { "content-type": "application/json", "accessToken": `Bareer ${get_access_token}` },
            body: CreateEmpCatData
        }).then((response) => {
            return response.json()
        }).then(async (response) => {
            if (response.messsage == "unauthorized") {
                await fetch(`${config['baseUrl']}/employment_category/AddEmploymentCategory`, {
                    method: "POST",
                    headers: { "content-type": "application/json", "refereshToken": `Bareer ${get_refresh_token}` },
                    body: CreateEmpCatData
                }).then(response => {
                    return response.json()
                }).then(response => {
                    secureLocalStorage.setItem("refresh", response.referesh_token);
                    secureLocalStorage.setItem("access_token", response.access_token);
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(response.messsage, "success")
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000)
                }).catch((errs) => {
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(errs.messsage, "warning")
                })
            }
            else if (response.messsage == "timeout error") { navigate('/') }
            else {
                setLoading(false);
                setBtnEnaledAndDisabled(false);
                showAlert(response.messsage, "success")
                setTimeout(() => {
                    window.location.reload();
                }, 1000)
            }
        }).catch((errs) => {
            setLoading(false);
            setBtnEnaledAndDisabled(false);
            showAlert(errs.messsage, "warning")
        })
}
const CreateEmpDesignationData = JSON.stringify({
    "Desig_code" : 0,
    "Desig_name": textInput.Designation_Name,
    "Desig_abbr": textInput.Designation_Abbr,
    "Sort_key": textInput.Sort_key,
    "Job_Evaluation_Flag": checkBoxInput.Job_Evaluation_Flag,
    "Dept_code": numberInput.Department_Code,
    "SatAllowance": numberInput.Sat_Allowance,
    "EveAllowance": numberInput.Eve_Allowance,
    "JD_Desig_Code": numberInput.JD_Designation_Code

})
    const CreateEmpDesignation = async (e) => {
        e.preventDefault();
        setLoading(true);
        setBtnEnaledAndDisabled(true);
        await fetch(`${config['baseUrl']}/employment_desig/AddEmploymentDesignation`, {
            method: "POST",
            headers: { "content-type": "application/json", "accessToken": `Bareer ${get_access_token}` },
            body: CreateEmpDesignationData
        }).then((response) => {
            return response.json()
        }).then(async (response) => {
            if (response.messsage == "unauthorized") {
                await fetch(`${config['baseUrl']}/employment_desig/AddEmploymentDesignation`, {
                    method: "POST",
                    headers: { "content-type": "application/json", "refereshToken": `Bareer ${get_refresh_token}` },
                    body: CreateEmpDesignationData
                }).then(response => {
                    return response.json()
                }).then(response => {
                    secureLocalStorage.setItem("refresh", response.referesh_token);
                    secureLocalStorage.setItem("access_token", response.access_token);
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(response.messsage, "success")
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000)
                }).catch((errs) => {
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(errs.messsage, "warning")
                })
            }
            else if (response.messsage == "timeout error") { navigate('/') }
            else {
                setLoading(false);
                setBtnEnaledAndDisabled(false);
                showAlert(response.messsage, "success")
                setTimeout(() => {
                    window.location.reload();
                }, 1000)
            }
        }).catch((errs) => {
            setLoading(false);
            setBtnEnaledAndDisabled(false);
            showAlert(errs.messsage, "warning")
        })
    }

    const CostCenterData = JSON.stringify({
        "Cost_Centre_code": 0,
        "Cost_Centre_name": textInput.Cost_Center_Name,
        "Cost_Centre_abbr": textInput.Cost_Centre_Abbr,
        "Train_Cost_Budget": numberInput.Train_Cost_Bugdet,
        "Train_Cost_Actual": numberInput.Train_Cost_Actual,
        "JV_Code1": textInput.JV_Code1,
        "JV_Code": textInput.JV_Code,
        "JVCode": textInput.JVCode,
        "Temporary_JV_Code": textInput.Temporary_JV_Code,
        "emp_category_1": numberInput.Employe_category_1,
        "emp_category_2": numberInput.Employe_category_2,
        "emp_category_3": numberInput.Employe_category_3,
        "Functional_Category_code": numberInput.Functional_Cat_Code,
        "Major_Code_Mgmt": textInput.Major_Code_Mgmt,
        "Major_Code_Union": textInput.Major_Code_Union,
        "Sort_key": textInput.Sort_Key,
        "total_cost_budget": numberInput.Total_Bugdet_Cost,
        "Azad_Kashmir_Tax_Flag": checkBoxInput.Azad_Kashmir_Tax_Flag,
        "Pay_Grade_Areas_code": numberInput.Pay_Grade_Areas_code,
        "Business_Sector_Code": numberInput.Business_Sector_Code,
        "org_unit_code": numberInput.org_unit_code,
    })
 
    const CreateCostCenterList = async (e) => {
        e.preventDefault();
        setLoading(true);
        setBtnEnaledAndDisabled(true);
        await fetch(`${config['baseUrl']}/employment_cost_center/AddCostCenter`, {
            method: "POST",
            headers: { "content-type": "application/json", "accessToken": `Bareer ${get_access_token}` },
            body: CostCenterData
        }).then((response) => {
            return response.json()
        }).then(async (response) => {
            if (response.messsage == "unauthorized") {
                await fetch(`${config['baseUrl']}/employment_cost_center/AddCostCenter`, {
                    method: "POST",
                    headers: { "content-type": "application/json", "refereshToken": `Bareer ${get_refresh_token}` },
                    body: CostCenterData
                }).then(response => {
                    return response.json()
                }).then(response => {
                    secureLocalStorage.setItem("refresh", response.referesh_token);
                    secureLocalStorage.setItem("access_token", response.access_token);
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(response.messsage, "success")
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000)
                }).catch((errs) => {
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(errs.messsage, "warning")
                })
            }
            else if (response.messsage == "timeout error") { navigate('/') }
            else {
                setLoading(false);
                setBtnEnaledAndDisabled(false);
                showAlert(response.messsage, "success")
                setTimeout(() => {
                    window.location.reload();
                }, 1000)
            }
        }).catch((errs) => {
            setLoading(false);
            setBtnEnaledAndDisabled(false);
            showAlert(errs.messsage, "warning")
        })
    }

    const GradeData = JSON.stringify({
        "Grade_code": 0,
        "Grade_name": textInput.Grade_Name,
        "Grade_abbr": textInput.Grade_Abbr,
        "ProbationMonths": numberInput.Probation_Months,    
        "Incentive_Hour_Rate": numberInput.Incentive_Hour_Rate,
        "Incentive_Weekdays_Limit_Hour": numberInput.Incentive_Weekdays_Limit_Hour,
        "Incentive_Saturday_Limit_Hour": numberInput.Incentive_Saturday_Limit_Hour,
        "Medical_Insurance_Amount": numberInput.Medical_Insurance_Amount,
        "Meal_Deduction": numberInput.Meal_Deduction,
        "Sort_key": textInput.Sort_Key,
        "Litres_for_Petrol": numberInput.Litres_For_Petrol,
        "Insurance_Category": textInput.Insurance_Category,
        "Life_Insurance_Category": textInput.Life_Insurance_Category,
        "Long_Name": textInput.Long_Name,
        "job_description_flag": checkBoxInput.Job_Description_Flag,
        "next_promotion_grade": numberInput.Next_Promotion_Grade,
        "Assigning_Critaria_For_Next_Promotion": numberInput.Assigning_Critaria_For_Next_Promotion,
        "Overtime_flag": textInput.Overtime_Flag,
        "mobile_amount": numberInput.Mobile_Amount,
        "Car_Amount": numberInput.Car_Amount
    })

    const CreateGradeList = async (e) => {
        e.preventDefault();
        // console.log("CreateGradeList", GradeData)
        // return
        setLoading(true);
        setBtnEnaledAndDisabled(true);
        await fetch(`${config['baseUrl']}/grade_code/AddGrade`, {
            method: "POST",
            headers: { "content-type": "application/json", "accessToken": `Bareer ${get_access_token}` },
            body: GradeData
        }).then((response) => {
            return response.json()
        }).then(async (response) => {
            if (response.messsage == "unauthorized") {
                await fetch(`${config['baseUrl']}/grade_code/AddGrade`, {
                    method: "POST",
                    headers: { "content-type": "application/json", "refereshToken": `Bareer ${get_refresh_token}` },
                    body: GradeData
                }).then(response => {
                    return response.json()
                }).then(response => {
                    secureLocalStorage.setItem("refresh", response.referesh_token);
                    secureLocalStorage.setItem("access_token", response.access_token);
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(response.messsage, "success")
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000)
                }).catch((errs) => {
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(errs.messsage, "warning")
                })
            }
            else if (response.messsage == "timeout error") { navigate('/') }
            else {
                setLoading(false);
                setBtnEnaledAndDisabled(false);
                showAlert(response.messsage, "success")
                setTimeout(() => {
                    window.location.reload();
                }, 1000)
            }
        }).catch((errs) => {
            setLoading(false);
            setBtnEnaledAndDisabled(false);
            showAlert(errs.messsage, "warning")
        })
    } 

    const InstituteData = JSON.stringify({
        "Inst_code": 0,
        "Inst_name": textInput.Institution_Name,
        "Inst_abbr": textInput.Institution_Abbrivation,
        "Inst_type": textInput.Institution_Type,
        "Inst_address_line1": textInput.Institution_Address_line1,
        "Inst_address_line2": textInput.Institution_Address_line2,
        "Inst_address_line3": textInput.Institution_Address_line3,
        "Inst_phone1": numberInput.Institution_Phone1,
        "Inst_phone2": numberInput.Institution_Phone2,
        "Inst_fax1": numberInput.Institution_Fax1,
        "Inst_fax2": numberInput.Institution_Fax2,
        "Inst_email": textInput.Institution_Email,
        "Inst_Web_Site": textInput.Institution_Website,
        "Sort_key": textInput.Short_Key,
        "Verification_Fee": numberInput.Verification_Fee
    })

    const CreateInstitute = async (e) => {
        e.preventDefault();
        setLoading(true);
        setBtnEnaledAndDisabled(true);
        await fetch(`${config['baseUrl']}/institutions/AddInstitution`, {
            method: "POST",
            headers: { "content-type": "application/json", "accessToken": `Bareer ${get_access_token}` },
            body: InstituteData
        }).then((response) => {
            return response.json()
        }).then(async (response) => {
            if (response.messsage == "unauthorized") {
                await fetch(`${config['baseUrl']}/institutions/AddInstitution`, {
                    method: "POST",
                    headers: { "content-type": "application/json", "refereshToken": `Bareer ${get_refresh_token}` },
                    body: InstituteData
                }).then(response => {
                    return response.json()
                }).then(response => {
                    secureLocalStorage.setItem("refresh", response.referesh_token);
                    secureLocalStorage.setItem("access_token", response.access_token);
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(response.messsage, "success")
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000)
                }).catch((errs) => {
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(errs.messsage, "warning")
                })
            }
            else if (response.messsage == "timeout error") { navigate('/') }
            else {
                setLoading(false);
                setBtnEnaledAndDisabled(false);
                showAlert(response.messsage, "success")
                setTimeout(() => {
                    window.location.reload();
                }, 1000)
            }
        }).catch((errs) => {
            setLoading(false);
            setBtnEnaledAndDisabled(false);
            showAlert(errs.messsage, "warning")
        })
    } 

    const CountryData = JSON.stringify({
        "Country_Code": 0,
        "Country_Name": textInput.Country_Name,
        "Country_Abbr": textInput.Country_Abbrivation,
        "SortKey": textInput.Sort_Key
    })
    const CreateCountry = async (e) => {
        e.preventDefault();
        setLoading(true);
        setBtnEnaledAndDisabled(true);
        await fetch(`${config['baseUrl']}/countries/AddCountry`, {
            method: "POST",
            headers: { "content-type": "application/json", "accessToken": `Bareer ${get_access_token}` },
            body: CountryData
        }).then((response) => {
            return response.json()
        }).then(async (response) => {
            if (response.messsage == "unauthorized") {
                await fetch(`${config['baseUrl']}/countries/AddCountry`, {
                    method: "POST",
                    headers: { "content-type": "application/json", "refereshToken": `Bareer ${get_refresh_token}` },
                    body: CountryData
                }).then(response => {
                    return response.json()
                }).then(response => {
                    secureLocalStorage.setItem("refresh", response.referesh_token);
                    secureLocalStorage.setItem("access_token", response.access_token);
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(response.messsage, "success")
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000)
                }).catch((errs) => {
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(errs.messsage, "warning")
                })
            }
            else if (response.messsage == "timeout error") { navigate('/') }
            else {
                setLoading(false);
                setBtnEnaledAndDisabled(false);
                showAlert(response.messsage, "success")
                setTimeout(() => {
                    window.location.reload();
                }, 1000)
            }
        }).catch((errs) => {
            setLoading(false);
            setBtnEnaledAndDisabled(false);
            showAlert(errs.messsage, "warning")
        })
    }    

    const DivisionData = JSON.stringify({
        "Div_code": 0,
        "Div_name": textInput.Division_Name,
        "Div_abbr": textInput.Division_Abbrivation,
        "Div_Head": numberInput.Division_Head,
        "Sort_key": textInput.Sort_Key,
        "division_category_code": numberInput.Division_Category_Code
    })

    const CreateDivisions = async (e) => {
        e.preventDefault();
        setLoading(true);
        setBtnEnaledAndDisabled(true);
        await fetch(`${config['baseUrl']}/division/AddDivision`, {
            method: "POST",
            headers: { "content-type": "application/json", "accessToken": `Bareer ${get_access_token}` },
            body: DivisionData
        }).then((response) => {
            return response.json()
        }).then(async (response) => {
            if (response.messsage == "unauthorized") {
                await fetch(`${config['baseUrl']}/division/AddDivision`, {
                    method: "POST",
                    headers: { "content-type": "application/json", "refereshToken": `Bareer ${get_refresh_token}` },
                    body: DivisionData
                }).then(response => {
                    return response.json()
                }).then(response => {
                    secureLocalStorage.setItem("refresh", response.referesh_token);
                    secureLocalStorage.setItem("access_token", response.access_token);
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(response.messsage, "success")
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000)
                }).catch((errs) => {
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(errs.messsage, "warning")
                })
            }
            else if (response.messsage == "timeout error") { navigate('/') }
            else {
                setLoading(false);
                setBtnEnaledAndDisabled(false);
                showAlert(response.messsage, "success")
                setTimeout(() => {
                    window.location.reload();
                }, 1000)
            }
        }).catch((errs) => {
            setLoading(false);
            setBtnEnaledAndDisabled(false);
            showAlert(errs.messsage, "warning")
        })
    }   


    const ReligionData = JSON.stringify({
        "Religion_code": 0,
        "Religion_name": textInput.Religion_Name,
        "Religion_abbr": textInput.Religion_Abbrivation,
        "Sort_key": textInput.Sort_Key
    })    

    const CreateReligion = async (e) => {
        e.preventDefault();
        setLoading(true);
        setBtnEnaledAndDisabled(true);
        await fetch(`${config['baseUrl']}/religion_code/AddReligion`, {
            method: "POST",
            headers: { "content-type": "application/json", "accessToken": `Bareer ${get_access_token}` },
            body: ReligionData
        }).then((response) => {
            return response.json()
        }).then(async (response) => {
            if (response.messsage == "unauthorized") {
                await fetch(`${config['baseUrl']}/religion_code/AddReligion`, {
                    method: "POST",
                    headers: { "content-type": "application/json", "refereshToken": `Bareer ${get_refresh_token}` },
                    body: ReligionData
                }).then(response => {
                    return response.json()
                }).then(response => {
                    secureLocalStorage.setItem("refresh", response.referesh_token);
                    secureLocalStorage.setItem("access_token", response.access_token);
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(response.messsage, "success")
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000)
                }).catch((errs) => {
                    setLoading(false);
                    setBtnEnaledAndDisabled(false);
                    showAlert(errs.messsage, "warning")
                })
            }
            else if (response.messsage == "timeout error") { navigate('/') }
            else {
                setLoading(false);
                setBtnEnaledAndDisabled(false);
                showAlert(response.messsage, "success")
                setTimeout(() => {
                    window.location.reload();
                }, 1000)
            }
        }).catch((errs) => {
            setLoading(false);
            setBtnEnaledAndDisabled(false);
            showAlert(errs.messsage, "warning")
        })
    }

useEffect(() => {
    setwhichForm(sessionStorage.getItem("whichForm"))
}, [])




    return (
        <>
            <div>
                <Header />
            </div>
            <div className="container p-3"></div>
            <div className="container p3 mt-5">
                <div className="container-fluid mt-2 EmployeeListContainer ">
                    <span className="EmployeeListHeader py-2">
                        Employee Type Form
                    </span>
                    <div className="row mt-2 p-3">
                        <form onSubmit={
                            whichForm == "CreateEmpType" ? CreateEmpType : 
                            whichForm == "CreateEmpCat" ? CreateEmpCat :
                            whichForm == "CreateEmpDesignation" ? CreateEmpDesignation :
                            whichForm == 'CreateCostCenterList' ? CreateCostCenterList :
                            whichForm == 'CreateGradeList' ? CreateGradeList :
                            whichForm == 'CreateInstitute' ? CreateInstitute :
                            whichForm == "CreateCountry" ? CreateCountry :
                            whichForm == "CreateDivisions" ? CreateDivisions :
                            whichForm == 'CreateReligion' ? CreateReligion :
                            whichForm == "empty"? "" : ""
                        }>
                            <ul className='p-0'>
                                {formErr && (
                                    <li className={`alert alert-${formErr.type}` + " " + "mt-1"}>{`${formErr.message}`}</li>
                                )}
                            </ul>
                            <div className="EmployeeTypeForm">
                                {convertData?.map((checkType,index) => {
                                    switch (checkType.type) {
                                        case 'text':
                                            return <div className="form-group mt-3">
                                                <label className='text-dark'>{checkType?.name}</label>
                                                <input type="text" name={checkType?.name} className="form-control" required
                                                    onChange={(e) => {
                                                        const originalString = e.target.name;
                                                        const stringWithoutSpaces = originalString.split(' ').join('_');
                                                        settextInput({
                                                            ...textInput,
                                                            [stringWithoutSpaces]: e.target.value == e.target.value ? e.target.value :  false,
                                                        });
                                                    }}
                                                />
                                            </div>;
                                        case 'number':
                                            switch (checkType?.name) {
                                                case "Retirement Age":
                                                    return <div className="form-group mt-3">
                                                        <label className='text-dark'>{checkType?.name}</label>
                                                        <input type="text" name={checkType?.name} className="form-control" required
                                                            onChange={(e) => {
                                                                const originalString = e.target.name;
                                                                const stringWithoutSpaces = originalString.split(' ').join('_');
                                                                setnumberInput({
                                                                    ...numberInput,
                                                                    [stringWithoutSpaces]: e.target.value.length  >= 10 ? e.target.value : false,
                                                                });
                                                            }}
                                                        />
                                                        <span>{numberInput.Retirement_Age > 10 ? "Plese type words less then 10 or equal  to ten" :  ""}</span>
                                                    </div>;
                                                    
                                            
                                                default:
                                                    return <div className="form-group mt-3">
                                                            <label className='text-dark'>{checkType?.name}</label>
                                                            <input type="number" name={checkType?.name} className="form-control" required
                                                                onChange={(e) => {
                                                                    const originalString = e.target.name;
                                                                    const stringWithoutSpaces = originalString.split(' ').join('_');
                                                                    setnumberInput({
                                                                        ...numberInput,
                                                                        [stringWithoutSpaces]: e.target.value == e.target.value ? e.target.value : false,
                                                                    });
                                                                }}
                                                            />
                                                        </div>;
                                            }
                                        case 'checkbox':
                                            return <div className="form-group mt-3">
                                                <label className='text-dark mx-2'>{checkType?.name}</label>
                                                <div className='form-control'>
                                                    <input type="Checkbox" name={checkType?.name} className="form-check-input" required
                                                        onChange={(e) => {
                                                            const originalString = e.target.name;
                                                            const stringWithoutSpaces = originalString.split(' ').join('_');
                                                            setCheckBoxInput({
                                                                ...checkBoxInput,
                                                                [stringWithoutSpaces]: e.target.type == e.target.type ? "Y" : "N",
                                                            });
                                                        }}
                                                />
                                                  <label className='text-dark mx-2'>{checkType?.value}</label>
                                                </div>
                                            </div>;
                                        case 'month':
                                            return <div className="form-group mt-3">
                                                <label className='text-dark'>{checkType?.name}</label>
                                                <input type="Month" name={checkType?.name} className="form-control" required
                                                    onChange={(e) => {
                                                        const originalString = e.target.name;
                                                        const stringWithoutSpaces = originalString.split(' ').join('_');
                                                        setdateInput({
                                                            ...dateInput,
                                                            [stringWithoutSpaces]: e.target.value == e.target.value ? e.target.value : false,
                                                        });
                                                    }}
                                                />
                                            </div>;
                                        case 'select':
                                            switch (checkType?.name) {
                                                case "Change Probation Month":
                                                    return <div className="form-group mt-3">
                                                        <label className='text-dark'>{checkType?.name}</label>
                                                        <select name={checkType?.name} className='form-select' required="true"
                                                            onClick={(e) => {
                                                                const originalString = e.target.name;
                                                                const stringWithoutSpaces = originalString.split(' ').join('_');
                                                                setselectTag({
                                                                    ...selectTag,
                                                                    [stringWithoutSpaces]: e.target.value == e.target.value ? e.target.value : false,
                                                                });
                                                            }}
                                                        >
                                                            <option value="Y">Y</option>
                                                            <option value="N">N</option>
                                                        </select>
                                                    </div>

                                                default:
                                                    return null
                                            }

                                        default:
                                            return null
                                    }
                                })}

                            </div>
                            <button
                                type="submit"
                                disabled={btnEnaledAndDisabled}
                                className="mt-3 btn btn-dark"
                            >
                                {loading ? "A moment please..." : "Submit"}
                            </button>
                        </form>

                    </div>
                </div>
            </div>
        </>
    )
}

export default EmpListForm