import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

// // Define an async thunk for API call
// export const fetchUserData = createAsyncThunk('user/fetchUserData', async () => {
//   const response = await fetch('your_api_endpoint');
//   const data = await response.json();
//   return data;
// });

// Create a slice
const UserSlice = createSlice({
  name: 'User',
  initialState: {
    userData: null,
    loading: false,
    error: null,
  },
  reducers: {},
});

console.log("UserSlice",UserSlice.actions)

export default UserSlice.reducer ;
// export { fetchUserData };